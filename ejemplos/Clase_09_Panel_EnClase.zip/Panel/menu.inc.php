<div class="navbar-default sidebar" role="navigation">
    <div class="sidebar-nav navbar-collapse">
        <ul class="nav" id="side-menu">
            <li>
                            <a href="#"><i class="fa fa-table fa-fw"></i>Listados con funciones <span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level collapse">
                                <li>
                                    <a href="listado_paises1.php">1) Listado Paises - ordenado</a>
                                </li>
                                <li>
                                    <a href="listado_niveles1.php">2) Listado Niveles - ordenado</a>
                                </li>
                                <li>
                                    <a href="listado_usuarios.html">3) Listado Usuarios - template </a>
                                </li>
                                <li>
                                    <a href="listado_usuarios.php">Tarea Nro 2: Listado Usuarios con PHP </a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
            </li>

            <li>
                <a href="registro.php"><i class="fa fa-dashboard fa-fw"></i> Form Registro</a>
            </li>

            
            

        </ul>
    </div>   
</div>    