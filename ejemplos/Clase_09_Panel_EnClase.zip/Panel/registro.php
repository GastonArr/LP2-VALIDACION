<?php 

/*

require_once 'funciones/select_paises.php';
$ListadoPaises = Listar_Paises($MiConexion);
$CantidadPaises= count($ListadoPaises);

require_once 'funciones/validacion_registro_usuario.php'; 



$Mensaje='';
$Estilo='warning';
if (!empty($_POST['BotonRegistrar'])) {
    //estoy en condiciones de poder validar los datos
    $Mensaje=Validar_Datos();
    if (empty($Mensaje)) {
        if (InsertarUsuarios($MiConexion) != false) {
            $Mensaje = 'Se ha registrado correctamente.';
            $_POST = array(); 
            $Estilo = 'success'; 
        }
    }
}*/

$Mensaje='';
$Estilo='';

require_once 'funciones/conexion.php';
require_once 'funciones/insertar_usuarios.php';
require_once 'funciones/select_paises.php'; 


$MiConexion=ConexionBD(); 

$ListadoPaises = Listar_Paises($MiConexion);
$CantidadPaises=count($ListadoPaises);


if (!empty($_POST['BotonRegistrar'])){
    //cuando pulse el boton entra en esta condicion
    if (empty($_POST['Nombre'])){
        $Mensaje='Debe ingresar el nombre. <br />';
        $Estilo='danger';
    }
    if (empty($_POST['Apellido'])){
        $Mensaje.='Debe ingresar el apellido. <br />';
        $Estilo='danger';
    } 
    if (empty($_POST['Email'])){
        $Mensaje.='Debe ingresar su correo. <br />';
        $Estilo='danger';
    } 
    if (empty($_POST['Pais'])) {
        $Mensaje.='Debe ingresar su pais de origen. <br />';
        $Estilo='danger';
    }
    
    if (empty($Mensaje)) {
        //habiendo pasado la validacion, podemos registrar en la tabla
        if (InsertarUsuarios($MiConexion) != false) {
            $Mensaje="Los datos se insertaron correctamente.";
            $Estilo='success'; 
        }
    }

}

require_once 'header.inc.php'; ?>

</head>

<body>

    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Pagina inicial</a>
            </div>
            <!-- /.navbar-header -->

            <?php require_once 'user.inc.php'; ?>
            <!-- /.navbar-top-links -->
            
            <?php require_once 'menu.inc.php'; ?>           
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Formulario de Registración</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Ingresa tus datos
                        </div>
                        <div class="panel-body">
                            <form role="form" method='post'>

                                <div class="row">
                                    <div class="col-lg-4" style="text-align: center;">
                                        <img src="dist/img/register.png" />
                                        <br />
                                    </div>
                                    <div class="col-lg-6">
                                        
                                        <?php if (!empty($Mensaje)) { ?>
                                        <div class="alert alert-<?php echo $Estilo; ?> alert-dismissable">
                                        <?php echo $Mensaje; ?>
                                        </div>
                                        <?php } ?>
                                        
                                        <div class="form-group">
                                            <label>Nombre:</label>
                                            <input class="form-control" type="text" name="Nombre" id="nombre" 
                                            value="<?php echo !empty($_POST['Nombre']) ? $_POST['Nombre'] : ''; ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Apellido:</label>
                                            <input class="form-control" type="text" name="Apellido" id="apellido" 
                                            value="<?php  
                                            if (!empty($_POST['Apellido']) ) {
                                                echo $_POST['Apellido'];
                                            } else {
                                                echo ''; 
                                            }  ?>">
                                        </div>

                                          <div class="form-group">
                                            <label>Email:</label>
                                            <input class="form-control" type="email" name="Email" id="email" 
                                            value="<?php echo !empty($_POST['Email']) ? $_POST['Email'] : ''; ?>">
                                        </div>

                                          <div class="form-group">
                                            <label>Pais</label>
                                            <select class="form-control" name="Pais" id="pais">
                                                <option value="">Selecciona...</option>
                                                <?php for($i=0 ; $i<$CantidadPaises ; $i++) { ?>
                                                <option value="<?php echo $ListadoPaises[$i]['Id'] ?>"><?php echo $ListadoPaises[$i]['Denominacion'] ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <button type="submit" class="btn btn-default" value="Registrar" name="BotonRegistrar" >Registrarme</button>
                                        o <a href="index.php">Volver al inicio</a>
                                    </div>
                                    <!-- /.row (nested) -->
                                </div>
                            </form>

                            <!-- /.panel-body -->
                        </div>
                        <!-- /.panel -->
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /#page-wrapper -->

        </div>
        <!-- /#wrapper -->

        <?php require_once 'footer.inc.php'; ?>