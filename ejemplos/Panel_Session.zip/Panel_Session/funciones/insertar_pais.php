<?php 
function InsertarPais($vConexion) {
        
    $SQL_Insert="INSERT INTO Paises (Denominacion)
    VALUES ('".$_POST['Nombre']."' )";


    if (!mysqli_query($vConexion, $SQL_Insert)) {
        //si surge un error, finalizo la ejecucion del script con un mensaje
        die ('<h4>Carga de pais: '. $SQL_Insert.'</h4> <p style="color: #ff0000">'.mysqli_error($vConexion) .'</p>'  ) ;
    }

    return true;
}
?>