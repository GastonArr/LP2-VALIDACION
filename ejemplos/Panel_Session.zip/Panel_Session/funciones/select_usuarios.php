<?php
function Listar_Usuarios($vConexion) {
     
    $Listado=array();
    //1) genero la consulta que deseo: esta usa el WHERE
    $SQL = "SELECT  U.Id as IdUser, U.Nombre, U.Apellido, U.Email,  U.Sexo, 
    P.Denominacion as Pais, N.Denominacion as Nivel, N.Id as IdNivel
        FROM usuarios U,  paises P, niveles N
        WHERE U.IdPais=P.Id 
        AND U.IdNivel = N.Id
        ORDER BY U.Apellido, U.Nombre";

//ESTA USA EL JOIN, AMBAS FUNCIONAN IGUAL TRAYENDO LOS CAMPOS INDICADOS EN EL SELECT
       $SQL = "SELECT  U.Id as IdUser , U.Nombre, U.Apellido, U.Email, U.Sexo, 
    P.Denominacion as Pais, N.Denominacion as Nivel, N.Id as IdNivel
        FROM usuarios U
            JOIN paises P 
            ON U.IdPais = P.Id 
            JOIN niveles N
            ON U.IdNivel = N.Id
        ORDER BY U.Apellido, U.Nombre";

    //2) a la conexion actual le brindo mi consulta, y el resultado lo entrego a variable $rs
     $rs = mysqli_query($vConexion, $SQL);
        
     //3) el resultado deberá organizarse en una matriz, entonces lo recorro
     $i=0;
    while ($data = mysqli_fetch_array($rs)) {
            $Listado[$i]['ID'] = $data['IdUser'];
            $Listado[$i]['NOMBRE'] = $data['Nombre'];
            $Listado[$i]['APELLIDO'] = $data['Apellido'];
            $Listado[$i]['EMAIL'] = $data['Email'];
            $Listado[$i]['PAIS'] = $data['Pais'];
            $Listado[$i]['SEXO'] = $data['Sexo'];
            $Listado[$i]['NIVEL'] = $data['Nivel'];
            $i++;
    }


    //devuelvo el listado generado en el array $Listado. (Podra salir vacio o con datos)..
    return $Listado;

}
?>