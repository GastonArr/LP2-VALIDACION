<?php
session_start();

if (empty($_SESSION['Usuario'] )) {
    header('Location: cerrarsesion.php');
    exit;
}

?>


<!DOCTYPE html>
<html lang="en">

<head>


</head>

<body>
   
 <h3>Tus datos de ingreso son: </h3>
 El usuario logueado es: <?php  echo $_SESSION['Usuario'] ; ?>
<br />
Nombre y apellido: <?php  echo $_SESSION['Nombre']. ' '. $_SESSION['Apellido'] ; ?> ; <br />
El Nivel es: <?php  echo $_SESSION['Nivel']; ?>

<br />
<?php 
if (!empty($_SESSION['Mensaje'])) {
    echo  '<h1>'.$_SESSION['Mensaje'].'</h1>'; 
}
?>
<?php require_once 'links.php'; ?>

    <h2>Esto es el index</h2>
   
    <hr />

</body>

</html>