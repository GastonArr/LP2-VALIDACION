
 <a href="cerrarsesion.php">cerrar sesion</a>
 <br />
 
 <hr />
    <a href="pagina1.php">Link a pagina 1</a> | 
    <a href="pagina2.php">Link a pagina 2</a> | 


    <?php if ($_SESSION['IdNivel'] !=2) { ?>
    <a href="pagina3.php">Link a pagina 3</a>
    <?php } ?>
    
    <hr />