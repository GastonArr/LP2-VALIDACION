<?php
session_start();
$Mensaje = "";


if (!empty($_POST["BotonLogin"] )) {
    //SE HA PULSADO EL BOTON
    if (empty($_POST["email"])) {
        $Mensaje = "Debe ingresar su mail o usuario.";
    }else if (empty($_POST["password"])) {
        $Mensaje = "Debe ingresar su clave.";
    }

    if (empty($Mensaje)) {
        if ($_POST["email"] == 'sue@gmail.com' && $_POST["password"]=='12345'){
            $_SESSION['Usuario'] = 'sue@gmail.com'; // $_POST["email"];
            $_SESSION["Nombre"] = 'Sue';
            $_SESSION['Apellido'] = 'Palacios';
            $_SESSION['Nivel'] = 'Operador';
            $_SESSION['IdNivel'] = 2; 

            /*
            nivel 1: admin - ver y entrar a todos lados
            nivel 2: operador: ver y entrar solo al index y la pagina1
            nivel 3: tecnico: ver y entrar solo al index y la pagina3
            */

            /*
            nivel 2: en la pagina 1 no debe ver la seccion donde esta la table
            nivel 2: no va a tener acceso a la pagina3
            */
            header('Location: index.php');
            exit();
            
        } else {
            $Mensaje = "Datos de acceso incorrectos.";
        }
    }

}

?>

<!DOCTYPE html>
<html lang="en">

<head>


</head>

<body>
    <form role="form" method='post'>
        <?php if (!empty($Mensaje)) { ?>
            <div class="alert alert-warning alert-dismissable">
                <?php echo $Mensaje; ?>
            </div>
        <?php } ?>
        <fieldset>
            <div class="form-group">
                <input class="form-control" placeholder="E-mail" name="email" type="text" autofocus value=''>
            </div>
            <div class="form-group">
                <input class="form-control" placeholder="Password" name="password" type="password">
            </div>

            <div class="form-group text-center">
                <button type="submit" class="btn btn-default" value="Login" name="BotonLogin">Ingresar</button>
            </div>

            <div class="form-group text-center">
                Si no tienes cuenta, puedes registrarte <a href="registro.php"> aqui</a>
            </div>
        </fieldset>
    </form>
    
    </body>
    </html>