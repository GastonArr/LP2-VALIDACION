<?php
session_start();

if (empty($_SESSION['Usuario'] )) {
    header(header: 'Location: cerrarsesion.php');
    exit;
}


?>


<!DOCTYPE html>
<html lang="en">

<head>


</head>

<body>


 <h3>Tus datos de ingreso son: </h3>
 El usuario logueado es: <?php  echo $_SESSION['Usuario'] ; ?>
<br />
Nombre y apellido: <?php  echo $_SESSION['Nombre']. ' '. $_SESSION['Apellido'] ; ?> ; <br />
El Nivel es: <?php  echo $_SESSION['Nivel']; ?>

<br />
<?php require_once 'links.php'; ?>
<?php

if ($_SESSION['IdNivel'] !=2 ) {
   ?> 
    <a href="pagina3.php">Link a pagina 3</a>
<?php } ?>

    <hr />

    <h2>Esto es la pagina 1</h2>
    
<?php

if ($_SESSION['IdNivel'] !=2 ) {
   ?> 

        <h2>Esto no debe ser visto por los Operadores</h2>
   <table>
    <tr>
        <td>col 1</td>
        <td>col 2</td>
    </tr>
        <tr>
        <td>dato 1</td>
        <td>dato 2</td>
    </tr>
   </table>
   
<?php } ?>

    <hr />

</body>

</html>