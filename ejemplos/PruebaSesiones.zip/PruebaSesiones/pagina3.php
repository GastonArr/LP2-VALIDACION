<?php
session_start();

if (empty($_SESSION['Usuario'] )) {
    header('Location: cerrarsesion.php');
    exit;
}


if ($_SESSION['IdNivel'] ==2 ) {
    $_SESSION['Mensaje'] = 'Ud. no tiene acceso a la pagina3';
    header('Location: index.php');
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">

<head>


</head>

<body>


 <h3>Tus datos de ingreso son: </h3>
 El usuario logueado es: <?php  echo $_SESSION['Usuario'] ; ?>
<br />
Nombre y apellido: <?php  echo $_SESSION['Nombre']. ' '. $_SESSION['Apellido'] ; ?> ; <br />

<?php require_once 'links.php'; ?>

    <h2>Esto es la pagina 3</h2>
   
    <hr />

</body>

</html>